import 'package:flutter/material.dart';

class Dumpy extends StatefulWidget {
  const Dumpy({super.key});

  @override
  State<Dumpy> createState() => _DumpyState();
}

class _DumpyState extends State<Dumpy> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
