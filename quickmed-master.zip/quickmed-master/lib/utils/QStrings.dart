class QStrings {
  QStrings._();

}